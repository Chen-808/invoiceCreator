let choresArray = []
let cost = 0
let carButton = document.getElementById("carButton")
let lawnButton = document.getElementById("lawnButton")
let weedButton = document.getElementById("weedButton")

function sendInvoice(){
    cost = 0
    choresArray = []
    //clear the textContent as well
}